/**
 * Created by Adrienne Crawford
 * Class: PWA
 * Goal: Goal7
 */

 
//constructor
//"window.Person=Person;"
//Person.jobs = (array 4 or more) 
//Person.actions = (arrays 4 or more verbs)
//properties: all set in constructor
//name = 
//action = actively doing. randomly select one from person.actions using Math.random
//job = randomly select one from Person.jobs using Math.random
//row = 

//instantiation
//display the initial action of person in 3rd column. 
 
 
//prototype
//call set interval in runupdate function
//ex function runUpdate(){
//people.forEach(function(element){
//element.update();
//display change in html column 3
//});
