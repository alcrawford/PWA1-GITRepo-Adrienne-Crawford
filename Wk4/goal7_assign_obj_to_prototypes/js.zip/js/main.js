/**
 * Created by Adrienne Crawford
 * Class: PWA
 * Goal: Goal7
 */

//In sum, there would be three Constructors, along with 3 instances of Instantiation to go with them 
and prototypes to detail them.

//Name r1c1 would be constructor 1- the plans
//Job r1c2 would be prototype to match above- add details
//Action r1c3 would be instantiation to create object based off above parameters

//Name r2c1 would be constructor 1- the plans
//Job r2c2 would be prototype to match above- add details
//Action r2c3 would be instantiation to create object based off above parameters

//Name r3c1 would be constructor 1- the plans
//Job r3c2 would be prototype to match above- add details
//Action r3c3 would be instantiation to create object based off above parameters/**


